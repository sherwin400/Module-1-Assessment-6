<?php
$otw_bsw_dialog_text = '';
?>