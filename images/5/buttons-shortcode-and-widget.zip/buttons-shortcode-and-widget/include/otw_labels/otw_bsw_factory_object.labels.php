<?php
$otw_bsw_factory_object->labels['License Details']=__('License Details', 'otw_bsw');
$otw_bsw_factory_object->labels['Domain']=__('Domain', 'otw_bsw');
$otw_bsw_factory_object->labels['Version']=__('Version', 'otw_bsw');
$otw_bsw_factory_object->labels['No information available']=__('No information available', 'otw_bsw');
$otw_bsw_factory_object->labels['Expires']=__('Expires', 'otw_bsw');
$otw_bsw_factory_object->labels['Product Code']=__('Product Code', 'otw_bsw');
$otw_bsw_factory_object->labels['Please confirm to deregister the code?']=__('Please confirm to deregister the code?', 'otw_bsw');
$otw_bsw_factory_object->labels['Delete Code']=__('Delete Code', 'otw_bsw');
$otw_bsw_factory_object->labels['Have a code, paste it here']=__('Have a code, paste it here', 'otw_bsw');
$otw_bsw_factory_object->labels['Submit Code']=__('Submit Code', 'otw_bsw');
$otw_bsw_factory_object->labels['No plugin information found.']=__('No plugin information found.', 'otw_bsw');
?>